clear all
close all
clc


fprintf('Progress...\n');
%getting address of mat files
dir_lafiz='D:\Thesis\Datasets\BCICIV_1calib_1000Hz_mat\';
%enter dir @abir


matfiles=dir(fullfile(strcat(dir_lafiz,'*.mat')));

%import data from file
[data1]=importdata(strcat(dir_lafiz, matfiles(1).name));
%size of data 
[m,n]=size(data1.cnt);

% for electrode=1:n
scatter((data1.nfo.xpos*0.1),(data1.nfo.ypos*0.1),100)

a=data1.nfo.clab';
% dx = 0.1; dy = 0.1;
text((data1.nfo.xpos*0.1),(data1.nfo.ypos*0.1),a)



% end


fprintf('\n')
