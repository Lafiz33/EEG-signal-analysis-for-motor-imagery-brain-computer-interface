clear all
close all
clc


fprintf('Progress...\n');
%getting address of mat files
dir_lafiz='D:\Thesis\Datasets\BCICIV_1calib_1000Hz_mat\';
%enter dir @abir


matfiles=dir(fullfile(strcat(dir_lafiz,'*.mat')));
%number of mat files
numfids = length(matfiles);


for i=1:numfids
    subject_num="subject"+i;
    file_name=strcat(subject_num,'.csv');
    %import data from file
    [data1]=importdata(strcat(dir_lafiz, matfiles(i).name));
    %size of data 
    [m,n]=size(data1.cnt);
    
    %for each of 200 epochs(row)
    mrkPosStart=[];
    mrkPosEnd=[];
    diff=data1.mrk.pos(2)-data1.mrk.pos(1);
    temp_value=zeros(200,240);
    
    for epoch=1:200
        chr=int2str(epoch);
        fprintf(strcat('epoch:',chr));
        mrkPosStart=data1.mrk.pos(epoch)+1;
        %if last one
        if epoch==200
            mrkPosEnd=length(data1.cnt);
        else
            mrkPosEnd=data1.mrk.pos(epoch+1);
        end
        %if epoch length is more than 8000 then it will cut it to first 8000
        if(diff<mrkPosEnd-mrkPosStart)
            mrkPosEnd=mrkPosStart+diff;
        end
        
%         half=idivide(uint16(mrkPosStart+mrkPosEnd),2);
        classLable=data1.mrk.y(epoch);
        
        %for each electord(column)
        %temp_value=zeros(1,240);
        index=4;
        index2=index+1;
        fprintf('\n')
        index=8;
        index2=(index+5);
        for electrode=1:n
            chr1=int2str(electrode);
            fprintf(strcat(chr1,',')); 
            %take 4000 size epoc
            mrkPosEnd = mrkPosStart+4000;
            %take epochs from each electrode at a time
            signal=data1.cnt(mrkPosStart:mrkPosEnd,electrode);
            
            %extract bands
            [Gamma1,Beta,Alpha,Theta1,Delta1] = getBand(signal,'db8');
%             beta1=Beta(mrkPosStart:half,:);
            
            %beta_dwt
            [cA,beta_D] = dwt(Beta,'sym4');
            ent_beta_dwt=entropy(beta_D);
        
            %beta_dct
            beta_dct=dct(Beta);
            beta_dct1=beta_dct(1:4000,1);
            ent_beta_dct=entropy(beta_dct.^2);
            
            %beta_fft
            beta_fft=real(fft(Beta));
            ent_beta_fft=entropy(beta_fft);
          
         
            %alpha_dwt
            [cA,alpha_D] = dwt(Alpha,'sym4');
            ent_alpha_dwt=entropy(alpha_D);
        
            %alpha_dct
            alpha_dct=dct(Alpha);
            alpha_dct=alpha_dct(1:4000,1);
            ent_alpha_dct=entropy(alpha_dct.^2);
            
            %alpha_fft
            alpha_fft=real(fft(Alpha));
            ent_alpha_fft=entropy(alpha_fft);
          
            
            
            %for each elecdrode 4 features
            
            %for first electrod add epoch start value and 4 features 
            if(electrode==1)
                temp_value(epoch,1:7)=[mrkPosStart,ent_beta_dwt,ent_beta_dct,ent_beta_fft,ent_alpha_dwt,ent_alpha_dct,ent_alpha_fft];
                %for each electrod/column 4 features will be added 
            elseif electrode<n
                %temp_value(1,index:index2)=[temp_value,ent_wvd_beta,ent_stft_beta,ent_wvd_alpha,ent_stft_alpha];
                temp_value(epoch,index:index2)=[ent_beta_dwt,ent_beta_dct,ent_beta_fft,ent_alpha_dwt,ent_alpha_dct,ent_alpha_fft];
                %changes index after inserting values
                index=index+6;
                index2=(index+5);
            else
                %an extra index for class lable
                index2=index2+1;
                temp_value(epoch,index:index2)=[ent_beta_dwt,ent_beta_dct,ent_beta_fft,ent_alpha_dwt,ent_alpha_dct,ent_alpha_fft,classLable];
            end
            
        subject_num="subject"+i;
        file_name=strcat(subject_num,'.csv');
%         writematrix(temp_value,file_name,'Delimiter','tab');
        csvwrite(file_name,temp_value);
        end
        fprintf('\n')
    end
end