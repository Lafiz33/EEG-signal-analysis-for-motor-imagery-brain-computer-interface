clear all
close all
clc


fprintf('Progress...\n');
%getting address of mat files
dir_lafiz='D:\Thesis\Datasets\BCICIV_1calib_1000Hz_mat\';
%enter dir @abir


matfiles=dir(fullfile(strcat(dir_lafiz,'*.mat')));
%number of mat files
numfids = length(matfiles);
temp_value=[];
epoch=1;
for i=1%:numfids
    subject_num="column_names";
    file_name=strcat(subject_num,'.csv');
    %import data from file
    [data1]=importdata(strcat(dir_lafiz, matfiles(i).name));
    %size of data 
    [m,n]=size(data1.cnt);
    index=6;
    index2=index+3;
    fprintf('\n')
%     elec_name="epoc ";
    elec_name="";
    str="";
    for electrode=1:n
       
       %take epochs from each electrode at a time
        elec_name1=string(data1.nfo.clab(electrode));
         if(elec_name1=='C5' || elec_name1=='C3'|| elec_name1=='Cz'|| elec_name1=='C2'|| elec_name1=='C4')
            %beta_dwt
            feature_1=strcat(elec_name1,"_beta_dwt,");

            %beta_dct
            feature_2=strcat(elec_name1,"_beta_dct,");

            %beta_fft
            feature_3=strcat(elec_name1,"_beta_fft,");
            %alpha_dwt
            feature_4=strcat(elec_name1,"_alpha_dwt,");

            %alpha_dct
            feature_5=strcat(elec_name1,"_alpha_dct,");

            %alpha_fft
            feature_6=strcat(elec_name1,"_alpha_fft,");

            elec_name=strcat(elec_name,feature_1,feature_2,feature_3,feature_4,feature_5,feature_6);
        end
        

        
    end
%     elec_name=strcat(elec_name,"class_lable");
%     str=split(elec_name);
%     str=str';
%     writetable(str','column_names_2.csv')
% %     csvwrite(file_name,str);
    
    fprintf('\n')
end