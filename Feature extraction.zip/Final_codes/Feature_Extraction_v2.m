clear all
close all
clc


fprintf('Progress...\n');
%getting address of mat files
dir_lafiz='D:\Thesis\Datasets\BCICIV_1calib_1000Hz_mat\';
%enter dir @abir


matfiles=dir(fullfile(strcat(dir_lafiz,'*.mat')));
%number of mat files
numfids = length(matfiles);


for i=1:numfids
    subject_num="subject"+i;
    file_name=strcat(subject_num,'.csv');
    %import data from file
    [data1]=importdata(strcat(dir_lafiz, matfiles(i).name));
    %size of data 
    [m,n]=size(data1.cnt);
    
    %for each of 200 epochs(row)
    mrkPosStart=[];
    mrkPosEnd=[];
    diff=data1.mrk.pos(2)-data1.mrk.pos(1);
    temp_value=zeros(200,240);
    
    for epoch=182:200
        chr=int2str(epoch);
        fprintf(strcat('epoch:',chr));
        mrkPosStart=data1.mrk.pos(epoch)+1;
        %if last one
        if epoch==200
            mrkPosEnd=length(data1.cnt);
        else
            mrkPosEnd=data1.mrk.pos(epoch+1);
        end
        %if epoch length is more than 8000 then it will cut it to first 8000
        if(diff<mrkPosEnd-mrkPosStart)
            mrkPosEnd=mrkPosStart+diff;
        end
        
        classLable=data1.mrk.y(epoch);
        
        %for each electord(column)
        %temp_value=zeros(1,240);
        index=6;
        index2=index+3;
        fprintf('\n')
        for electrode=1:n
            chr1=int2str(electrode);
            fprintf(strcat(chr1,',')); 
            %take epochs from each electrode at a time
            signal=data1.cnt(mrkPosStart:mrkPosEnd,electrode);
            
            %extract bands
            [Gamma1,Beta,Alpha,Theta1,Delta1] = getBand(signal,'db8');
            
            %Wigner-Ville distribution & entropy of beta 
            [d_beta,f,t]=wvd(Beta);
            ent_wvd_beta=entropy(d_beta);
            
            %Short-time Fourier transform & entropy of beta
            [stft_beta, f, t] = stft(Beta, 100, 200, 100, 1000);
            ent_stft_beta=entropy(real(stft_beta));
          
            %Wigner-Ville distribution & entropy of alpha 
            [d_alpha,f,t]=wvd(Alpha);
            ent_wvd_alpha=entropy(d_alpha);
            
            %Short-time Fourier transform & entropy of beta
            [stft_alpha, f, t] = stft(Alpha, 100, 200, 100, 1000);
            ent_stft_alpha=entropy(real(stft_alpha));
            
            %for each elecdrode 4 features
            
            %for first electrod add epoch start value and 4 features 
            if(electrode==1)
                temp_value(epoch,1:5)=[mrkPosStart,ent_wvd_beta,ent_stft_beta,ent_wvd_alpha,ent_stft_alpha];
                %for each electrod/column 4 features will be added 
            elseif electrode<n
                %temp_value(1,index:index2)=[temp_value,ent_wvd_beta,ent_stft_beta,ent_wvd_alpha,ent_stft_alpha];
                temp_value(epoch,index:index2)=[ent_wvd_beta,ent_stft_beta,ent_wvd_alpha,ent_stft_alpha];
                %changes index after inserting values
                index=index+4;
                index2=(index+3);
            else
                %an extra index for class lable
                index2=index2+1;
                temp_value(epoch,index:index2)=[ent_wvd_beta,ent_stft_beta,ent_wvd_alpha,ent_stft_alpha,classLable];
            end
            
        subject_num="subject"+i;
        file_name=strcat(subject_num,'.csv');
%         writematrix(temp_value,file_name,'Delimiter','tab');
        csvwrite(file_name,temp_value);
        end
        fprintf('\n')
    end
end