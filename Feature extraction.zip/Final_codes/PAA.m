function data=PAA(signal,EpochSize)

N=length(signal);
no_of_Block=abs(N/EpochSize);
sN=reshape(signal,no_of_Block,EpochSize);
avg=mean(sN);
data=repmat(avg,no_of_Block,1);
data=data(:);