%Annotations calculation
clear all
close all
clc

fprintf('Progress...\n');
string1='D:\Thesis\Datasets\BCICIV_1calib_1000Hz_mat\';
%string1='';
matfiles=dir(fullfile(strcat(string1,'*.mat')));
numfids = length(matfiles);
features_final=zeros(11900,6);
value=zeros(200,6);
for i = 1%:numfids
    fprintf('.');
    [data1] = importdata(strcat(string1, matfiles(i).name));
    
    [m,n]=size(data1.cnt);
    
    %featureAllAll=[];
    
    for column=1:n 
       
       featureAll=[];
       mrkPosStart=[];
       mrkPosEnd=[];
       diff=data1.mrk.pos(2)-data1.mrk.pos(1);
       for j=15:200      
          
          mrkPosStart=data1.mrk.pos(j)+1;
          if j==200
            mrkPosEnd=length(data1.cnt);
          else
              mrkPosEnd=data1.mrk.pos(j+1);
          end
           if(diff<mrkPosEnd-mrkPosStart)
               mrkPosEnd=mrkPosStart+diff;
           end
%           check=mod(j,15);
%           if check==0
%               continue;
%           end
%           
%           check=mod(j,100);
%           if check==0
%               continue;
%           end

          classLabel=data1.mrk.y(j);
          signal=data1.cnt(mrkPosStart:mrkPosEnd,column);
          
          [Gamma1,Beta,Alpha,Theta1,Delta1] = getBand(signal,'db8');
          %Beta=PAA(Beta1,100);
          %Alpha=PAA(Alpha1,100);
         
          
          [d_beta,f,t]=wvd(Beta);
          [stft_beta, f, t] = stft(Beta, 100, 200, 100, 1000);
          ent_wvd_beta=entropy(d_beta);
          ent_stft_beta=entropy(real(stft_beta));
          
          [d_alpha,f,t]=wvd(Alpha);
          [stft_alpha, f, t] = stft(Alpha, 100, 200, 100, 1000);
          ent_wvd_alpha=entropy(d_alpha);
          ent_stft_alpha=entropy(real(stft_alpha));

          value(j,1:6)=[mrkPosStart,ent_wvd_beta,ent_stft_beta,ent_wvd_alpha,ent_stft_alpha,classLabel ];
          
%           %%%Feature Extraction
%           feature1=mean(signal);
%           %feature2=std(signal);
%           feature3=median(signal);
%           %% add features
%           featureAdd=[feature1 feature3];
%           
%           
%           featureAll=[featureAll;featureAdd];
          
          
          %plot(signal)
       
       end
       electrode_name=string(data1.nfo.clab(1,column));
       string2=(strcat(electrode_name,'.xls'));
       xlswrite(string2, value);
%          featureAllAll=[featureAllAll featureAll];
    end
       
end  

% featureAllAll=[featureAllAll featureAll];
%     [m,n]=size(data1.data); %size of the file, i.e., rows and columns
%     k=1;%initial value
%     annotationsCalculate=[];
%     m1=floor(m/10);
%     for j=1:10:m1*10
%          %Start(2) Stop(3) Door(4) RoundDoor(5) NarrowSpace(6) OpenSapce(7) OpenSpaceH(8)
%          %Elevator(9) Stairs(10) RoundStairs(11) Assistance(12) MovingPeople(13) MovingObject(14)
%          %LegHeight(15) HeadHeight(16) BlockedPassage(17) LoudSound(18) FindButton(19)
%          newAnnoValue=[k sum(data1.data(j:j+9,2)) sum(data1.data(j:j+9,3)) sum(data1.data(j:j+9,4))+sum(data1.data(j:j+9,5))...
%                            sum(data1.data(j:j+9,6)) sum(data1.data(j:j+9,7))+sum(data1.data(j:j+9,8)) sum(data1.data(j:j+9,9))...
%                            sum(data1.data(j:j+9,10))+sum(data1.data(j:j+9,11)) sum(data1.data(j:j+9,13))+sum(data1.data(j:j+9,14))...
%                             sum(data1.data(j:j+9,18)) sum(data1.data(j:j+9,12)) sum(data1.data(j:j+9,15)) sum(data1.data(j:j+9,16))...
%                             sum(data1.data(j:j+9,17)) sum(data1.data(j:j+9,19))];
%          annotationsCalculate=[annotationsCalculate;newAnnoValue];
%        
%          k=k+1;
%     end
%     
%     %calculate starting point
%     [r,c]=find(annotationsCalculate(:,2)>0);
%      if length(r)>1
%         r=r(2);
%      end
%      AnnStartTime=[AnnStartTime;r];
%      %calculate ending point
%     if sum(annotationsCalculate(:,3))>0
%         [r1,c1]=find(annotationsCalculate(:,3)>0);
%          if length(r1)>1
%             r1=r1(1);
%          end
%          
%     else
%         r1=length(annotationsCalculate(:,3));
%     end
%     
%     if i==4
%         %annotations calculation after starting and ending point
%         totalAnnotationsCalculate=[totalAnnotationsCalculate;annotationsCalculate(r:r1-5,:)];
%         %length of annotations for feature extraction
%         annotationLength1=length(annotationsCalculate(r:r1-5,:)); 
%         
%     else
%         %annotations calculation after starting and ending point
%         totalAnnotationsCalculate=[totalAnnotationsCalculate;annotationsCalculate(r:r1,:)];
%         %length of annotations for feature extraction
%         annotationLength1=length(annotationsCalculate(r:r1,:));    
%     end
%     annotationLength=[annotationLength,annotationLength1];
% end
%     
% %labelling
% %Features(14) Door NarrowSpace OpenSpace Elevator Staris MovingObject LoudSound 
%     
% for k=1:length(totalAnnotationsCalculate)
%  LabellingAnnotations(k,:)=[totalAnnotationsCalculate(k,1:3) totalAnnotationsCalculate(k,4:10)== max(totalAnnotationsCalculate(k,4:10))];
% end
% 
% 
% %totalAnnotationsCalculate
% 
% % EEG signal and annotations start time.
% matfiles1=dir(fullfile('C:\Users\zavid.parvez\Google Drive\Thesis_\Group 1\Code\DataFiles\WalkStartEndTimes.csv'));
% [data2] = importdata(strcat('C:\Users\zavid.parvez\Google Drive\Thesis_\Group 1\Code\DataFiles\', matfiles1(1).name));
% 
% %Pick data from data2 for starting starting time by the person; format is data type and textdata type
% EEGStart=[];
% UnixTimeStart=[];
% statingTimeBySubject=[];
% for i=2:26
%     %EEG start calculation in hour, minute and second
%     s=data2.textdata(i,5);
%     str=cell2mat(s);
%     C = textscan(str,'%f:%f:%f');
%     c1=[i-1 C{1} C{2} C{3}];
%     EEGSecond=c1(2)*3600+c1(3)*60+c1(4);
%     %EEGStart=[EEGStart;c1];
%     
%     %unix calculation in hour, minute and second
%     s=unixtime(data2.data(i-1,1));
%     c1=[i-1 s(4) s(5) s(6)];
%     UnixSecond=c1(2)*3600+c1(3)*60+c1(4);
%     UnixTimeStart=[UnixTimeStart;c1];
%     
%     statingTimeBySubject1=UnixSecond-EEGSecond;
%     statingTimeBySubject=[statingTimeBySubject;statingTimeBySubject1];
% end
% 
% %Consider EEG signals for feature extraction
% 
% %subject each subjectwise
% subject=[1 1 1 2 2 2 3 3 4 4 4 5 5 5 6 6 6 7 7 8 8 8 9 9 9]; %subject 1/2/4/5/6/9/10 (3 trials) and subject 3/8 (2 trials)
% trial=[1 2 3 1 2 3 1 2 1 2 3 1 2 3 1 2 3 1 2 1 2 3 1 2 3];
% 
% matfilesRestingState=dir(fullfile('C:\Users\zavid.parvez\Google Drive\Thesis_\Group 1\Code\DataFiles\resting_states\*.mat'));
% numfidsRestingState = length(matfilesRestingState);
% 
% % for kk=1:numfidsRestingState 
% %     dataRestingState = importdata(strcat('C:\Users\MohammadZavid\Documents\AnalysisIndoorAndOutdoorData\indoor_mar16_VIP\resting_states\', matfilesRestingState(kk).name));
% % end
% 
% matfiles=dir(fullfile('C:\Users\zavid.parvez\Google Drive\Thesis_\Group 1\Code\DataFiles\UnixTimeWithEEG\Signals\*.txt'));
% numfids = length(matfiles);
% signal=[];
% %start and end position for each patient for labelling
% startt=1;
% endd=annotationLength(1);
% Features=[];
% fprintf('\n');
% 
% for ii =1:numfids
%     fprintf('.');
%     %[dataEEG,header] = lab_read_edf(strcat('C:\Users\MohammadZavid\Documents\AnalysisIndoorAndOutdoorData\indoor_mar16_VIP\epoc_detrend\', matfiles(ii).name));
%     [dataEEG,header] = importdata(strcat('C:\Users\zavid.parvez\Google Drive\Thesis_\Group 1\Code\DataFiles\UnixTimeWithEEG\Signals\', matfiles(ii).name));
%     %for j=statingTimeBySubject(ii)*128+1:(annotationLength(ii)+statingTimeBySubject(ii))*128 %length of eeg signal considered
%     Features2=[];
%     dataRestingState = importdata(strcat('C:\Users\zavid.parvez\Google Drive\Thesis_\Group 1\Code\DataFiles\resting_states\', matfilesRestingState(subject(ii)).name));
%     dataEEG=dataEEG';
%     for k=7:20 %14 channel consider
%           signal=dataEEG(k,statingTimeBySubject(ii)*128+1:(annotationLength(ii)+statingTimeBySubject(ii))*128);
%           
%           %Pre-procsssing
%           signal=signal-mean(dataRestingState(:,k-6));
%           
%           %divided different band
%           waveletFunction = 'db8'; 
%           [Gamma,Beta,Alpha,Theta,Delta]=getBand(signal,waveletFunction);
%           %[Gamma,Beta,Alpha,Theta,Delta]=getBandLatest(signal); %original signal
%           [GammaRest,BetaRest,AlphaRest,ThetaRest,DeltaRest]=getBand(dataRestingState(:,k-6),waveletFunction); %resting state     
%                     
%           
%           %Feature Extraction Entropy
%           %  EntropyGamma= petropyTotal(Gamma);
%           %  EntropyBeta= petropyTotal(Beta);
%           %  EntropyAlpha= petropyTotal(Alpha);
%           %  EntropyTheta= petropyTotal(Theta);
%           %  EntropyDelta= petropyTotal(Delta);
%           %  Features11=[EntropyGamma EntropyBeta EntropyAlpha EntropyTheta EntropyDelta];
%             
%           %Feature Extraction Entropy
%             PowerGamma= totalPower(Gamma);
%             PowerBeta= totalPower(Beta);
%             PowerAlpha= totalPower(Alpha);
%             PowerTheta= totalPower(Theta);
%             PowerDelta= totalPower(Delta);
%             Features11=[PowerGamma PowerBeta PowerAlpha PowerTheta PowerDelta];
%           
%          %Feature Extraction Cognitive Index
%             CIGamma= cognitiveIndex(Gamma,GammaRest)';
%             CIBeta= cognitiveIndex(Beta,BetaRest)';
%             CIAlpha= cognitiveIndex(Alpha,AlphaRest)';
%             CITheta= cognitiveIndex(Theta,ThetaRest)';
%             CIDelta= cognitiveIndex(Delta,DeltaRest)';
%             Features22=[CIGamma CIBeta CIAlpha CITheta CIDelta];
%             
%             Features1=[Features11 Features22]; %add two kind of features
%             
%             Features2=[Features2 Features1]; %all features
%     end   
%     
%     %Features and labelling add
%     len=length(Features2);
%     %Fetures: Features(1-140:
%     %channels(AF3,F7,F3,FC5,T7,P7,O1,O2,P8,T8,FC6,F4,F8,AF4),
%     %bands (gamma,beta,alpha,theta,delta),entropy/cognitiveindex, 
%     %i.e. AF3: EntropyGamma EntropyBeta EntropyAlpha EntropyTheta EntropyDelta
%     %          CIGamma CIBeta CIAlpha CITheta CIDelta, F7:...,AF3:...), 
%     %label(141-147:Door,NarrowSpace,OpenSpace, Elevator, Stairs, Moving,Sound), 
%     %subject number:148, trial number:149, time stamp:150
%     timeStamp=floor(dataEEG(1,statingTimeBySubject(ii)*128+1)/1000)...
%         :floor(dataEEG(1,statingTimeBySubject(ii)*128+1)/1000)+annotationLength(ii)-1;
%     Features3=[Features2 LabellingAnnotations(startt:endd,4:10) subject(ii)*ones(len,1) trial(ii)*ones(len,1) timeStamp'];
%     Features=[Features;Features3];
%     
%     if ii<=24
%         startt=endd+1;
%         endd=startt+annotationLength(ii+1)-1;
%     end
% end
% 
% %To add index of the Features
% index=1:length(Features);
% 
%  %Fetures: index(1),Features(2-141:
%     %channels(AF3,F7,F3,FC5,T7,P7,O1,O2,P8,T8,FC6,F4,F8,AF4),
%     %bands (gamma,beta,alpha,theta,delta),entropy/cognitiveindex, 
%     %i.e. AF3: EntropyGamma(2) EntropyBeta(3) EntropyAlpha(4)
%     %EntropyTheta(5) EntropyDelta(6)
%     %CIGamma(7) CIBeta(8) CIAlpha(9) CITheta(10) CIDelta(11), F7:...12-21...,AF3:...), 
%     %label(142-148:Door,NarrowSpace,OpenSpace, Elevator, Stairs, Moving,Sound), 
%     %subject number:149, trial number:150
%     
% Features=[index' Features];
% %Save all features
% fileID = fopen(strcat('C:\Users\zavid.parvez\Google Drive\Thesis_\Group 1\Code\DataFiles\UnixTimeExtractedFeatures\PowerCogIndexFeatures.txt'),'wt');
% 
% for L = 1:size(Features,1)
%         fprintf(fileID,'%d\t',Features(L,:));
%         fprintf(fileID,'\n');
% end
% 
% fclose(fileID);
% 
