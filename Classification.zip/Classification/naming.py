# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 01:27:00 2019

@author: Lenovo
"""
#with open("names.txt","r") as file:
#    data=file.readlines()
##    x=data.split(",")
#    print(data[2])


f = open('names.txt')
# use readline() to read the first line 
line = f.readline()
# use the read line to read further.
# If the file is not empty keep reading one line
# at a time, till the file is empty
while line:
    # in python 2+
    # print line
    # in python 3 print is a builtin function, so
    a=(line.replace(",",", "))
    # use realine() to read next line
    line = f.readline()
f.close()
x=a.split(", ")
print(x)