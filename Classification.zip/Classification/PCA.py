# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 23:56:06 2019

@author: Lenovo
"""

from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split,cross_val_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA 
import pandas as pd
from sklearn import tree

#taking column names from names.txt 
f = open('names2.txt')
# use readline() to read the first line 
line = f.readline()
names=line.split(",")
temp=''

names.remove('')  

#read data
data = pd.read_csv("subject7_110.csv")

#takes features as predictors form column 2 to 237 
X=data[names]
Y=data['class_lable']
#splits dataset into 70:30 train test portion
X_train, X_test, y_train, y_test = train_test_split( 
          X, Y, test_size = 0.3, random_state = 300)

pca = PCA(n_components = 4) 
  
X_train = pca.fit_transform(X_train) 
X_test = pca.transform(X_test) 

explained_variance = pca.explained_variance_ratio_


classifier = LogisticRegression(random_state = 0) 
#corss val score for liner svm
score = cross_val_score(classifier,X,Y,cv=10,scoring='accuracy')
print("cv score : ",score.mean())
logsitic_reg = classifier.fit(X_train, y_train)

y_pred = logsitic_reg.predict(X_test) 

print("explained_variance : ", explained_variance)

#calculate accuracy
print("Confusion matrix : ",
      confusion_matrix(y_test, y_pred))
print("Accuracy : ",
      accuracy_score(y_test,y_pred)*100)
print("report : ",
      classification_report(y_test,y_pred))




