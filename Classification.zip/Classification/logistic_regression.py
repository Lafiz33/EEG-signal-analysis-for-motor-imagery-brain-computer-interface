# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 23:38:21 2019

@author: Lenovo
"""

from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split,cross_val_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.linear_model import LogisticRegression
import pandas as pd
from sklearn import tree
from sklearn.metrics import roc_curve, auc
import pylab as pl
from sklearn.metrics import roc_auc_score  
from matplotlib import pyplot
import matplotlib.pyplot as plt

#taking column names from names.txt 
f = open('names2.txt')
# use readline() to read the first line 
line = f.readline()
names=line.split(",")
temp=''

names.remove('')  
#read data
data = pd.read_csv("subject1_110.csv")

#takes features as predictors form column 2 to 237 
X=data[names]
Y=data['class_lable']
#splits dataset into 70:30 train test portion
X_train, X_test, y_train, y_test = train_test_split( 
          X, Y, test_size = 0.2, random_state = 0)

logreg=LogisticRegression();
#corss val score for liner svm
score = cross_val_score(logreg,X,Y,cv=10,scoring='accuracy')
print("cv score : ",score.mean()*100)
logistic_reg = logreg.fit(X_train, y_train)

y_pred = logreg.predict(X_test)

print('Accuracy {:.2f}'.format(logreg.score(X_test, y_test)*100))

#y_pred1=logistic_reg.predict_proba(X_test)
#probs= y_pred1[:, 1]    
#print(probs)
#
#def plot_roc_curve(fpr, tpr):  
#    pyplot.figure(figsize=(20,10))
#    plt.plot(fpr, tpr, color='orange', label='ROC')
#    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
#    plt.xlabel('False Positive Rate')
#    plt.ylabel('True Positive Rate')
#    plt.title('Receiver Operating Characteristic (ROC) Curve')
#    plt.legend()
#    plt.show()
##
#auc1 = roc_auc_score(y_test, y_pred1[:,1])  
#print('AUC: %.2f' % auc1)      
#fpr, tpr, thresholds = roc_curve(y_test, y_pred1[:,1])  
#plot_roc_curve(fpr, tpr)


