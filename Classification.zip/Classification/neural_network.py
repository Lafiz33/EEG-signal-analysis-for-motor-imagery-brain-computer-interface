# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 12:29:07 2019

@author: Lenovo
"""
import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split,cross_val_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.metrics import roc_auc_score  
from sklearn.metrics import roc_curve, auc

#taking column names from names.txt 
f = open('names2.txt')
# use readline() to read the first line 
line = f.readline()
names=line.split(",")
temp=''

names.remove('')  

#read data
data = pd.read_csv("subject1.csv")
data=data.head(70)

#takes features as predictors form column 2 to 237 
X=data[names]

Y=data['class_lable']
#splits dataset into 70:30 train test portion
X_train, X_test, y_train, y_test = train_test_split( 
          X, Y, test_size = 0.20, random_state = 0)

neuron=200

classifier = MLPClassifier(hidden_layer_sizes=(neuron,neuron,neuron,neuron), max_iter=500)

#score = cross_val_score(classifier,X,Y,cv=10,scoring='accuracy')
#print("cv score : ",score.mean())

nn = classifier.fit(X_train, y_train)

#predicting test result
y_pred = nn.predict(X_test)
#calculate accuracy
print("Confusion matrix : ",
      confusion_matrix(y_test, y_pred))
print("Accuracy : ",
      accuracy_score(y_test,y_pred)*100)
print("report : ",
      classification_report(y_test,y_pred))

#y_pred1=nn.predict_proba(X_test)
#probs= y_pred1[:, 1]    
#print(probs)
#
#def plot_roc_curve(fpr, tpr):  
#    plt.figure(figsize=(20,10))
#    plt.plot(fpr, tpr, color='orange', label='ROC')
#    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
#    plt.xlabel('False Positive Rate')
#    plt.ylabel('True Positive Rate')
#    plt.title('Receiver Operating Characteristic (ROC) Curve')
#    plt.legend()
#    plt.show()
##
##auc = roc_auc_score(y_test, probs[:,1])  
##print('AUC: %.2f' % auc)      
#fpr, tpr, thresholds = roc_curve(y_test, probs)  
#plot_roc_curve(fpr, tpr)

