# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 20:01:13 2019

@author: lafiz33
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split,cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.externals import joblib

#taking column names from names.txt 
f = open('names2.txt')
# use readline() to read the first line 
line = f.readline()
names=line.split(",")
temp=''

names.remove('')  
#read data
data = pd.read_csv("subject7_110.csv")

#takes features as predictors form column 2 to 237 
X=data[names]
Y=data['class_lable']
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size = 0.25, random_state = 21)

#feature scaling
#subtracts the mean value of the observation
#then divides it by the unit variance of the observation.

#better option
#X_scaled = preprocessing.scale(X_train)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Fitting Random Forest Classification to the Training set
classifier = RandomForestClassifier(n_estimators = 10, criterion = 'entropy', random_state = 300)

score = cross_val_score(classifier,X,Y,cv=10,scoring='accuracy')
print("cv score : ",score.mean()*100)

rForest = classifier.fit(X_train, y_train)


#predicting test result
y_pred = rForest.predict(X_test)
#calculate accuracy
print("Confusion matrix : ",
      confusion_matrix(y_test, y_pred))
print("Accuracy : ",
      accuracy_score(y_test,y_pred)*100)
print("report : ",
      classification_report(y_test,y_pred))


#Reverse factorize (converting y_pred from 0s,1s and 2s to Iris-setosa, Iris-versicolor and Iris-virginica
#reversefactor = dict(zip(range(3),definitions))
#y_test = np.vectorize(reversefactor.get)(y_test)
#y_pred = np.vectorize(reversefactor.get)(y_pred)
## Making the Confusion Matrix
#print(pd.crosstab(y_test, y_pred, rownames=['Actual Species'], colnames=['Predicted Species']))

#storing trained model
#print(list(zip(dataset.columns[0:4], classifier.feature_importances_)))
#joblib.dump(classifier, 'randomforestmodel.pkl') 