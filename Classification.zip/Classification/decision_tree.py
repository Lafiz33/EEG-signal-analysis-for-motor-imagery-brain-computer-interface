# -*- coding: utf-8 -*-
"""
Spyder Editor

@author: lafiz33
"""

from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA 
import pandas as pd
from sklearn import tree
from sklearn.metrics import roc_curve, auc
import pylab as pl
from sklearn.metrics import roc_auc_score  
from matplotlib import pyplot
import matplotlib.pyplot as plt


#taking column names from names.txt 
f = open('names2.txt')
# use readline() to read the first line 
line = f.readline()
names=line.split(",")
temp=''

names.remove('')  

#read data
data = pd.read_csv("subject7.csv")
data=data.head(166)
#takes features as predictors form column 2 to 237 
X=data[names]
#data['class_lable'] = data['class_lable'].map({1:1,-1:0})
Y=data['class_lable']
#splits dataset into 70:30 train test portion
X_train, X_test, y_train, y_test = train_test_split( 
          X, Y, test_size = 0.2, random_state = 0)

pca = PCA(n_components = 6) 
  
X_train = pca.fit_transform(X_train) 
X_test = pca.transform(X_test) 

explained_variance = pca.explained_variance_ratio_

#train with entropy
decisionTreeClassifier = tree.DecisionTreeClassifier(criterion="entropy")

#score = cross_val_score(decisionTreeClassifier,X,Y,cv=10,scoring='accuracy')
#print("cv score : ",score.mean()*100)

dTree = decisionTreeClassifier.fit(X_train, y_train)

#test
y_pred=dTree.predict(X_test)

#calculate accuracy
print("Confusion matrix : ",
      confusion_matrix(y_test, y_pred))
#pl.matshow(confusion_matrix(y_test, y_pred))
#pl.title('Confusion matrix of the classifier')
#pl.colorbar()
#pl.show()
print("Accuracy : ",
      accuracy_score(y_test,y_pred)*100)
print("report : ",
      classification_report(y_test,y_pred))

#fpr, tpr, thresholds = roc_curve(y_test, y_pred)



#
#y_pred1=dTree.predict_proba(X_test)
#probs= y_pred1[:, 1]    
#def plot_roc_curve(fpr, tpr):  
#    pyplot.figure(figsize=(20,10))
#    plt.plot(fpr, tpr, color='orange', label='ROC')
#    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
#    plt.xlabel('False Positive Rate')
#    plt.ylabel('True Positive Rate')
#    plt.title('Receiver Operating Characteristic (ROC) Curve')
#    plt.legend()
#    plt.show()
##
#auc1 = roc_auc_score(y_test, y_pred1[:,1])  
#print('AUC: %.2f' % auc1)      
#fpr, tpr, thresholds = roc_curve(y_test, y_pred1[:,1])  
#plot_roc_curve(fpr, tpr)


#pyplot.figure(figsize=(20,10))
## plot no skill
#pyplot.plot([0, 1], [0, 1], linestyle='--')
## plot the roc curve for the model
#pyplot.plot(fpr, tpr, marker='.')
## show the plot
#pyplot.show()

    
    