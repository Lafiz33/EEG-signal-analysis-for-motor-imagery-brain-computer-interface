# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 21:00:02 2019

@author: lafiz33
"""

import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split,cross_val_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.datasets.samples_generator import make_blobs
from sklearn.metrics import roc_curve, auc
import pylab as pl
from sklearn.metrics import roc_auc_score

#taking column names from names.txt 
f = open('names2.txt')
# use readline() to read the first line 
line = f.readline()
names=line.split(",")
temp=''

names.remove('')  
#read data
data = pd.read_csv("subject1.csv")
data=data.head(85)

#takes features as predictors form column 2 to 237 
X=data[names]
Y=data['class_lable']

X=np.array(X)
Y=np.array(Y)
#splits dataset into 70:30 train test portion
X_train, X_test, y_train, y_test = train_test_split( 
          X, Y, test_size = 0.2)

#y_test=[-1,-1,1,1,-1,-1,-1,1,1,-1,1,-1,-1,1,-1,1,-1]
print(y_test)
#liner SVM
svclassifier = SVC(kernel='linear',probability=True)
#corss val score for liner svm
#score = cross_val_score(svclassifier,X,Y,cv=10,scoring='accuracy')
#print("cv score linear : ",score.mean())

liner_svm = svclassifier.fit(X_train, y_train)

#polynomial kernel SVM
svclassifier = SVC(kernel='poly', degree=8,probability=True)

#corss val score for liner svm
#score = cross_val_score(svclassifier,X,Y,cv=10,scoring='accuracy')
#print("cv score poly : ",score.mean())

poly_svm = svclassifier.fit(X_train, y_train)



y_pred_liner = liner_svm.predict(X_test)
y_pred_poly = poly_svm.predict(X_test)


print("Accuracy liner: ",
      accuracy_score(y_test,y_pred_liner)*100)
print("Accuracy poly: ",
      accuracy_score(y_test,y_pred_poly)*100)



#y_test_proba = poly_svm.predict_proba(X_test)
## print(y_test_proba)
#fpr, tpr, threshold = roc_curve(y_test,y_test_proba[:,1])
#plt.figure()
#plt.figure(figsize=(20,10))
#plt.plot(fpr,tpr)
#plt.show()

y_test_proba = poly_svm.predict_proba(X_test)
# print(y_test_proba)
fpr, tpr, threshold = roc_curve(y_test,y_test_proba[:,1])
np.savetxt("tpr1.csv",fpr, delimiter=",")
np.savetxt("fpr1.csv",tpr, delimiter=",")
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.figure()
plt.figure(figsize=(20,20))
plt.plot(fpr,tpr)
plt.show()
