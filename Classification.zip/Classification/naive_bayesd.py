# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 15:07:46 2019

@author: Lenovo
"""

import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split,cross_val_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report

#taking column names from names.txt 
f = open('names2.txt')
# use readline() to read the first line 
line = f.readline()
names=line.split(",")
temp=''

names.remove('')  

#read data
data = pd.read_csv("subject7_110.csv")

#takes features as predictors form column 2 to 237 
X=data[names]
Y=data['class_lable']
#splits dataset into 70:30 train test portion
X_train, X_test, y_train, y_test = train_test_split( 
          X, Y, test_size = 0.20, random_state = 0)

classifier=GaussianNB()

score = cross_val_score(classifier,X,Y,cv=10,scoring='accuracy')
print("cv score : ",score.mean()*100)

gnb=classifier.fit(X_train,y_train)

#predicting test result
y_pred = gnb.predict(X_test)
#calculate accuracy
print("Confusion matrix : ",
      confusion_matrix(y_test, y_pred))
print("Accuracy : ",
      accuracy_score(y_test,y_pred)*100)
print("report : ",
      classification_report(y_test,y_pred))